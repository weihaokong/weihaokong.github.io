function main()                                    %main function
    setting=4;                                     %1=identity,2=two spike, 3=uniform, 4=Toeplitz
    p=500;                                         %dimension
    n=500;                                         %sample size
    k = 10;                                        %moments order
    for i=1:k                                      %set scaling factor for each moment
        f_k(i) = max(p^(i/2-1),1)/n^(i/2)*(2*i)^(2*i); 
    end
    switch setting
        case 1
            S = diag(sqrt(ones(1,p)));                       %identity
        case 2
            S = diag(sqrt([2*ones(1,p/2) 1*ones(1,p-p/2)])); %two spike
        case 3
            S = diag(sqrt([0:1/(p-1)*2:1*2]));               %uniform
        case 4                                               %Toeplitz
            T = zeros(p,p);
            for i=1:p
                for j=1:p
                    T(i,j) = 0.3^(abs(i-j));
                end
            end
            [U,D,~]=svd(T);
            S = U*D^(1/2)*U';  
    end
    Sigma = S'*S;
    H_real = compute_moment(svd(Sigma)',k);        %real spectral moments     
    [real_pos, real_pdf] = to_measure(svd(Sigma)');%real spectral pdf
    real_cdf = pdf2cdf(real_pdf);                  %convert to spectral cdf
    X = randn(p,n);                                %generate iid gaussian
    tic
    H = compute_moment_by_cycle(X'*S'*S*X,k,p);    %estimate spectral moments
    x = 0:0.01:3;                                  %support of recovered measure
    [rec_pdf,t] = recover_density(H,x,f_k);        %recover spectral distribution
    dis_rec_pdf = pdf2vec(rec_pdf,p);              %convert to pdf which corresponds to a vector
    dis_rec_cdf = pdf2cdf(dis_rec_pdf);            
    dis_rec_err(i) = earthmover(x,dis_rec_pdf,real_pos,real_pdf); %earthmover distance between real and recovered distribution

    hold on
    ylim([0 1]);
    stairs([0 x],[0 dis_rec_cdf],'r');
    stairs([0 real_pos],[0 real_cdf],'b');
    h=legend('Estimated Spectral Distribution','Population Spectral Distribution','Location','southeast');
    hold off
    fprintf('Earthmover distance error: %d\n',mean(dis_rec_err));
    toc
end