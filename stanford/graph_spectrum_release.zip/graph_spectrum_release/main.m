% generate an Erd?s?R�nyi with 500 nodes and p=0.1
p = 0.1;
n = 500;
G = triu(binornd(1,p,500,500),1);
G = G+G';
deg = zeros(n,1);
start = zeros(n,1);
edgelist = [];
start(1) = 1;
for i = 1:n
    elist = find(G(i,:))';
    deg(i) = size(elist,1);
    start(i+1) = start(i)+deg(i);
    elist = [i*ones(deg(i),1),elist];
    edgelist = [edgelist; elist];
end
start = start(1:n);

% create a mesh of size 1001
n_grid = 1001;
x = zeros(1,n_grid);
for t =1:n_grid
    x(t) = cos((2*t-1)/(2*n_grid)*pi);
end
x = flip(x);

% 1000 walks, each walk has 20 steps
s = 1000;
k = 20;
% recover the eigenvalue distribution
rec_pdf = est_graph_spectrum(edgelist,deg,start,s,k,x);
rec_cdf = pdf2cdf(rec_pdf);

figure
hold on
scatter(rec_cdf,1-x);
% compute groundtrurth
L = eye(n)-diag(deg)^(-1/2)*G*diag(deg)^(-1/2);
scatter(1/n:1/n:1,svd(L));
legend('ground-truth','recovery');
hold off
