%% Input
% edgelist: m by 2 matrix, list of edges sorted by the start node
% deg: size n vector contains the degree of each node
% start: size n vector, start(i) is the position of the first edge of node
% i in edgelist
% s: number of walks
% k: number of steps of each walk
% x: support of the eigenvalues distribution 
function ag_pdf = est_graph_spectrum(edgelist,deg,start,s,k,x)
    n = size(deg,1);
    ag_pdf = zeros(size(x));
    n_trial=20;
    for trial = 1:n_trial
        H=0;
        x_count = zeros(1,k);
        for i=1:s
            j = randi(n);
            w = j;
            for step = 1:k
                w = edgelist(start(w)+randi(deg(w))-1,2);
                if (w==j)
                    x_count(step)=x_count(step)+1;
                end
            end
        end
        for i = 1:k
            H(i) = x_count(i)/s;
        end
        [rec_pdf,t] = recover_density(H,x,ones(1,k));        %recover spectral distribution         
        ag_pdf = ag_pdf+rec_pdf;
    end
    ag_pdf = ag_pdf/n_trial;
end