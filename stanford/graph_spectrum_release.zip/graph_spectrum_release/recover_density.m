function [pdf,t] = recover_density(H,x,f_k)
%%     version 2: minimize L_1 distance
    k = size(H,2);
    ns = size(x,2);
    V = ones(k,ns);
    V(1,:) = x;
    
    for i=2:k
        V(i,:) = V(i-1,:).*x;
    end
    A = [V,-eye(k),zeros(k,1);
        -V,-eye(k),zeros(k,1);
        ones(1,ns),zeros(1,k),-1;
        -ones(1,ns),zeros(1,k),-1];
    b = [H';-H';1;-1];
    f = [zeros(1,ns),f_k, 1];
    lb = zeros(ns+k+1,1);
    Hnorm = eye(ns)/10;
    Hnorm(ns+k,ns+k)=0;
    options = optimoptions('linprog','OptimalityTolerance',1e-10);
    [res,fval] = linprog(f,A,b,[],[],lb,[],[],options);
    pdf = res(1:ns)';    
    t = b(1:k)-V*res(1:ns);
end